# MIR_HW1

Discusstions: [here](https://hackmd.io/p1LSI4XUTISlXZt_nhsm_w?both#httpshackmdiojcIQHKVCRPO6uCAvCdqTDwboth-MIR-Hw1)